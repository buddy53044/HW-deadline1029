#include <stdio.h>
#include <stdlib.h>
#include<math.h>

int main()
{
	int a, b, c;
	int count = 0;

	for (a = 1; a<=500; a++)
	{
		for (b = 1;b<=500; b++)
		{
			for (c = 1; c <= 500; c++)
			{
				if (a*a + b * b == c * c)
					printf("count%d:\t%d %d %d\n",++count, a, b, c);
			}
		}
	}


	system("pause");
	return 0;
}